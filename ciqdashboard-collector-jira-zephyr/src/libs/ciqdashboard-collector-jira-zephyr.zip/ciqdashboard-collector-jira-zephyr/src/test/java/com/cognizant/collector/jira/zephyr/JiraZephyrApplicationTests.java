package com.cognizant.collector.jira.zephyr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JiraZephyrApplicationTests {

	@Test
	void contextLoads() {
	}

}
